from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

admission_info = {
    "requirements": "Applicants must have completed high school with a minimum GPA of 3.0. English proficiency is required.",
    "deadlines": "Fall Semester: July 31, Spring Semester: December 15",
    "programs": "We offer programs in Computer Science, Engineering, Business, Arts, and Sciences.",
    "scholarships": "Merit-based and need-based scholarships are available.",
    "contact": "Email: admissions@university.edu | Phone: +1234567890"
}

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_message = request.json.get("message", "").lower()
    response = "I'm sorry, I didn't understand that. You can ask about requirements, deadlines, programs, scholarships, or contact info."

    if "requirement" in user_message:
        response = admission_info["requirements"]
    elif "deadline" in user_message:
        response = admission_info["deadlines"]
    elif "program" in user_message:
        response = admission_info["programs"]
    elif "scholarship" in user_message:
        response = admission_info["scholarships"]
    elif "contact" in user_message:
        response = admission_info["contact"]

    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)
