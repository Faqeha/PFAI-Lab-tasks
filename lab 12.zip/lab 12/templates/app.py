import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
from flask import Flask, render_template, request

QNA_DATA = [
    ("What is Python used for?", "Python is a high-level, interpreted programming language used for web development, data analysis, AI, machine learning, and automation scripts."),
    ("Explain the difference between a list and a tuple.", "A list is a mutable collection (can be changed after creation), while a tuple is an immutable collection (cannot be changed after creation)."),
    ("What is Git?", "Git is a distributed version control system for tracking changes in source code during software development and coordinating work among developers."),
    ("What is the purpose of an 'if' statement?", "An 'if' statement is used to execute a block of code only if a specified condition is true."),
    ("How does a neural network learn?", "A neural network learns by adjusting the weights and biases of its nodes (neurons) through a process called backpropagation, minimizing the difference between its predictions and the actual target values."),
]

QUESTIONS = [item[0] for item in QNA_DATA]
ANSWERS = [item[1] for item in QNA_DATA]

MODEL_NAME = 'all-MiniLM-L6-v2'
model = SentenceTransformer(MODEL_NAME)

question_embeddings = model.encode(QUESTIONS, convert_to_numpy=True)
dimension = question_embeddings.shape[1]

index = faiss.IndexFlatL2(dimension)
index.add(question_embeddings)

def semantic_search(query_text, k=3):
    query_embedding = model.encode([query_text], convert_to_numpy=True)
    distances, indices = index.search(query_embedding, k)
    results = []
    for i, idx in enumerate(indices[0]):
        results.append({
            'rank': i + 1,
            'question': QUESTIONS[idx],
            'answer': ANSWERS[idx],
            'distance': f"{distances[0][i]:.4f}"
        })
    return results

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def home():
    results = []
    query = ""
    if request.method == 'POST':
        query = request.form.get('query')
        if query:
            results = semantic_search(query, k=3)
    return render_template('index.html', results=results, query=query)

if __name__ == '__main__':
    app.run(debug=True)
